---
title:      【JS基础整理】事件Event
date: 2022-12-31 15:52:24
tags:
    - JavaScript
    - Event
description:  JavaScript基础知识整理——事件的应用

---

## 前言

事件

## 正文

事件

## 后记

事件

---  

[1]: http://www.w3school.com.cn/jsref/dom_obj_event.asp